import uuid
from collections.abc import Sequence
from typing import Callable, Optional

import jax
import jax.numpy as jnp
from gymnax import EnvParams

# Defensive: see ajax/agents/base.py for rationale (broken wandb install
# must not crash Ajax imports — TensorBoard-only runs should still work).
try:
    import wandb  # type: ignore[import-untyped]
except ImportError:
    wandb = None  # type: ignore[assignment]

from ajax.agents.AVG.state import AVGConfig
from ajax.agents.AVG.train_AVG import make_train
from ajax.environments.create import prepare_env
from ajax.environments.utils import (
    check_if_environment_has_continuous_actions,
    get_action_dim,
)
from ajax.extensions.base import Extension, ExtensionStack
from ajax.logging.wandb_logging import (
    LoggingConfig,
    init_logging,
    stop_async_logging,
    with_wandb_silent,
)
from ajax.modules.pid_actor import PIDActorConfig
from ajax.state import AlphaConfig, EnvironmentConfig, NetworkConfig, OptimizerConfig
from ajax.types import EnvType


class AVG:
    """Action Value Gradient (AVG) from Vasan et al. 2024. See https://arxiv.org/abs/2411.15370"""

    def __init__(  # pylint: disable=W0102, R0913
        self,
        env_id: str | EnvType,  # TODO : see how to handle wrappers?
        n_envs: int = 1,
        actor_learning_rate: float = 6.3e-3,
        critic_learning_rate: float = 8.7e-3,
        alpha_learning_rate: float = 3e-4,
        actor_architecture=("256", "leaky_relu", "256", "leaky_relu"),
        critic_architecture=("256", "leaky_relu", "256", "leaky_relu"),
        gamma: float = 0.99,
        env_params: Optional[EnvParams] = None,
        max_grad_norm: Optional[float] = None,
        learning_starts: int = 0,
        reward_scale: float = 1.0,
        alpha_init: float = 0.07,
        target_entropy_per_dim: float = -1.0,
        lstm_hidden_size: Optional[int] = None,
        beta_1: float = 0,
        beta_2: float = 0.999,
        num_critics: int = 1,
        expert_policy: Optional[Callable] = None,
        pid_actor_config: Optional[PIDActorConfig] = None,
        action_pipeline: Optional[Callable] = None,
        eval_action_transform: Optional[Callable] = None,
        target_modifier: Optional[Callable] = None,
        obs_preprocessor: Optional[Callable] = None,
        policy_action_transform: Optional[Callable] = None,
        # Gap A (Phase 4a): expose the most recent ``(T=1, n_envs, ...)``
        # rollout transition on ``agent_state.last_rollout``. Off by
        # default — see :attr:`BaseAgentState.last_rollout`.
        expose_recent_rollout: bool = False,
        # --- New surface: composable research features as Extensions ---
        extensions: Sequence[Extension] = (),
    ) -> None:
        """
        Initialize the AVG agent.

        Args:
            env_id (str | EnvType): Environment ID or environment instance.
            n_envs (int): Number of parallel environments.
            learning_rate (float): Learning rate for optimizers.
            actor_architecture (tuple): Architecture of the actor network.
            critic_architecture (tuple): Architecture of the critic network.
            gamma (float): Discount factor for rewards.
            env_params (Optional[EnvParams]): Parameters for the environment.
            max_grad_norm (Optional[float]): Maximum gradient norm for clipping.
            learning_starts (int): Timesteps before training starts.
            reward_scale (float): Scaling factor for rewards.
            alpha_init (float): Initial value for the temperature parameter.
            target_entropy_per_dim (float): Target entropy per action dimension.
            lstm_hidden_size (Optional[int]): Hidden size for LSTM (if used).
        """
        self.config = {**locals()}
        self.config.update({"algo_name": "AVG"})

        # AVG builds its own configs without going through ActorCritic's
        # __init__, so it must enforce the memory guard itself. Recurrent
        # AVG is deliberately unsupported: its fully-incremental
        # single-transition updates give length-1 BPTT, so memory weights
        # cannot learn temporal structure without eligibility traces/RTRL.
        if lstm_hidden_size is not None:
            raise NotImplementedError(
                "AVG does not support recurrent networks (memory /"
                " lstm_hidden_size); supported agents: PPO, SAC, ASAC,"
                " REDQ, TD3."
            )

        env, env_params, env_id, continuous = prepare_env(
            env_id,
            env_params=env_params,
            normalize_obs=True,
            normalize_reward=False,
            n_envs=n_envs,
            gamma=gamma,
        )

        if not check_if_environment_has_continuous_actions(env):
            raise ValueError("AVG only supports continuous action spaces.")

        self.env_args = EnvironmentConfig(
            env=env,
            env_params=env_params,
            n_envs=n_envs,
            continuous=continuous,
        )

        self.alpha_args = AlphaConfig(
            learning_rate=alpha_learning_rate,
            alpha_init=alpha_init,
        )

        self.network_args = NetworkConfig(
            actor_architecture=actor_architecture,
            critic_architecture=critic_architecture,
            lstm_hidden_size=lstm_hidden_size,
            squash=True,
            penultimate_normalization=True,
        )

        self.actor_optimizer_args = OptimizerConfig(
            learning_rate=actor_learning_rate,
            max_grad_norm=max_grad_norm,
            clipped=max_grad_norm is not None,
            beta_1=beta_1,
            beta_2=beta_2,
        )
        self.critic_optimizer_args = OptimizerConfig(
            learning_rate=critic_learning_rate,
            max_grad_norm=max_grad_norm,
            clipped=max_grad_norm is not None,
            beta_1=beta_1,
            beta_2=beta_2,
        )
        action_dim = get_action_dim(env, env_params)
        target_entropy = target_entropy_per_dim * action_dim
        self.agent_config = AVGConfig(
            gamma=gamma,
            learning_starts=learning_starts,
            target_entropy=target_entropy,
            reward_scale=reward_scale,
            num_critics=num_critics,
            expose_recent_rollout=expose_recent_rollout,
        )

        self.expert_policy = expert_policy
        self.pid_actor_config = pid_actor_config
        self.action_pipeline = action_pipeline
        self.eval_action_transform = eval_action_transform
        self.target_modifier = target_modifier
        self.obs_preprocessor = obs_preprocessor
        self.policy_action_transform = policy_action_transform
        # Composable research features (mirrors ActorCritic base). AVG
        # defines its own __init__ rather than inheriting from
        # ActorCritic, so the stack is built here.
        self.extension_stack = ExtensionStack(extensions)

    @with_wandb_silent
    def train(
        self,
        seed: int | Sequence[int] = 42,
        n_timesteps: int = int(1e6),
        num_episode_test: int = 10,
        logging_config: Optional[LoggingConfig] = None,
    ) -> None:
        """
        Train the SAC agent.

        Args:
            seed (int | Sequence[int]): Random seed(s) for training.
            n_timesteps (int): Total number of timesteps for training.
            num_episode_test (int): Number of episodes for evaluation during training.
        """
        if isinstance(seed, int):
            seed = [seed]

        if logging_config is not None:
            logging_config.config.update(self.config)
            _gen_id = (
                wandb.util.generate_id
                if wandb is not None
                else lambda: uuid.uuid4().hex
            )
            run_ids = [_gen_id() for _ in range(len(seed))]
            for run_id in run_ids:
                init_logging(run_id, logging_config)
        else:
            run_ids = None

        def set_key_and_train(seed, index):
            key = jax.random.PRNGKey(seed)

            train_jit = make_train(
                env_args=self.env_args,
                actor_optimizer_args=self.actor_optimizer_args,
                critic_optimizer_args=self.critic_optimizer_args,
                network_args=self.network_args,
                agent_config=self.agent_config,
                total_timesteps=n_timesteps,
                alpha_args=self.alpha_args,
                num_episode_test=num_episode_test,
                run_ids=run_ids,
                logging_config=logging_config,
                expert_policy=self.expert_policy,
                pid_actor_config=self.pid_actor_config,
                action_pipeline=self.action_pipeline,
                eval_action_transform=self.eval_action_transform,
                target_modifier=self.target_modifier,
                obs_preprocessor=self.obs_preprocessor,
                policy_action_transform=self.policy_action_transform,
                extensions=tuple(self.extension_stack.extensions),
            )

            agent_state = train_jit(key, index)
            stop_async_logging()
            return agent_state

        index = jnp.arange(len(seed))
        seed = jnp.array(seed)
        return jax.vmap(set_key_and_train, in_axes=0)(seed, index)


if __name__ == "__main__":
    n_seeds = 1
    log_frequency = 5000
    n_envs = 128
    logging_config = LoggingConfig(
        project_name="avg_multi_env",
        run_name="test",
        config={
            "debug": False,
            "log_frequency": log_frequency,
            "n_seeds": n_seeds,
            "num_envs": n_envs,
        },
        log_frequency=log_frequency,
        horizon=10_000,
        use_tensorboard=False,
    )
    env_id = "halfcheetah"
    avg_agent = AVG(
        env_id=env_id,
        n_envs=n_envs,
    )
    avg_agent.train(
        seed=list(range(n_seeds)),
        n_timesteps=int(1e6),
        logging_config=logging_config,
    )
