import os
from collections.abc import Sequence
from dataclasses import fields
from typing import Any, Callable, Dict, Optional, Tuple

import jax
import jax.numpy as jnp
from flax import struct
from flax.core import FrozenDict
from flax.serialization import to_state_dict
from flax.training.train_state import TrainState
from jax.tree_util import Partial as partial

from ajax.agents.AVG.state import AVGConfig, AVGState, NormalizationInfo
from ajax.agents.AVG.utils import compute_td_error_scaling
from ajax.environments.interaction import (
    Transition,
    collect_experience,
    get_pi,
    init_collector_state,
    should_use_uniform_sampling,
)
from ajax.environments.utils import check_env_is_gymnax, get_state_action_shapes
from ajax.extensions.base import ExtensionStack
from ajax.log import compose_eval_metrics, evaluate_and_log
from ajax.logging.wandb_logging import (
    LoggingConfig,
    start_async_logging,
    vmap_log,
)
from ajax.modules.pid_actor import PIDActorConfig
from ajax.networks.networks import (
    get_adam_tx,
    get_initialized_actor_critic,
    predict_value,
)
from ajax.perf_utils import train_jit
from ajax.state import (
    AlphaConfig,
    EnvironmentConfig,
    LoadedTrainState,
    NetworkConfig,
    OptimizerConfig,
    zeros_like_abstract_pytree,
)

PROFILER_PATH = "./tensorboard"


def get_alpha_from_params(params: FrozenDict) -> float:
    return jnp.exp(params["log_alpha"])


@struct.dataclass
class TemperatureAuxiliaries:
    alpha_loss: jax.Array
    alpha: jax.Array
    log_alpha: jax.Array


@struct.dataclass
class PolicyAuxiliaries:
    policy_loss: jax.Array
    log_pi: jax.Array
    q_min: jax.Array


@struct.dataclass
class ValueAuxiliaries:
    critic_loss: jax.Array
    q_pred: jax.Array
    target_q: jax.Array
    log_probs: jax.Array
    scaling_coef: jax.Array


@struct.dataclass
class AuxiliaryLogs:
    temperature: TemperatureAuxiliaries
    policy: PolicyAuxiliaries
    value: ValueAuxiliaries


def create_alpha_train_state(
    learning_rate: float = 3e-4,
    alpha_init: float = 1.0,
) -> TrainState:
    """
    Initialize the train state for the temperature parameter (alpha).

    Args:
        learning_rate (float): Learning rate for alpha optimizer.
        alpha_init (float): Initial value for alpha.

    Returns:
        TrainState: Initialized train state for alpha.
    """
    log_alpha = jnp.log(alpha_init)
    params = FrozenDict({"log_alpha": log_alpha})
    tx = get_adam_tx(learning_rate)
    return TrainState.create(
        apply_fn=get_alpha_from_params,  # Optional
        params=params,
        tx=tx,
    )


# @partial(
#     jax.jit,
#     static_argnames=[
#         "num_critics",
#         "window_size",
#         "alpha_args",
#         "network_args",
#         "actor_optimizer_args",
#         "critic_optimizer_args",
#         "env_args",
#     ],
# )
def init_AVG(
    key: jax.Array,
    env_args: EnvironmentConfig,
    actor_optimizer_args: OptimizerConfig,
    critic_optimizer_args: OptimizerConfig,
    network_args: NetworkConfig,
    alpha_args: AlphaConfig,
    num_critics: int = 1,
    window_size: int = 10,
    pid_actor_config: Optional[PIDActorConfig] = None,
) -> AVGState:
    """
    Initialize the SAC agent's state, including actor, critic, alpha, and collector states.

    Args:
        key (jax.Array): Random number generator key.
        env_args (EnvironmentConfig): Environment configuration.
        optimizer_args (OptimizerConfig): Optimizer configuration.
        network_args (NetworkConfig): Network configuration.
        alpha_args (AlphaConfig): Alpha configuration.

    Returns:
        AVGState: Initialized SAC agent state.
    """
    (
        rng,
        init_key,
        collector_key,
    ) = jax.random.split(key, num=3)

    actor_state, critic_state = get_initialized_actor_critic(
        key=init_key,
        env_config=env_args,
        actor_optimizer_config=actor_optimizer_args,
        critic_optimizer_config=critic_optimizer_args,
        network_config=network_args,
        continuous=True,
        action_value=True,
        squash=True,
        num_critics=num_critics,
        pid_actor_config=pid_actor_config,
    )
    mode = "gymnax" if check_env_is_gymnax(env_args.env) else "brax"

    collector_state = init_collector_state(
        collector_key, env_args=env_args, mode=mode, window_size=window_size
    )

    alpha = create_alpha_train_state(**to_state_dict(alpha_args))

    init_val = jnp.zeros(
        (env_args.n_envs, 1)
    )  # a single dim as we are normalizing scalars (gamma, reward, G_return) (1 scalar for all envs)

    init_norm_info = NormalizationInfo(
        value=init_val,
        count=jnp.zeros((1,)),
        mean=jnp.zeros((1, 1)),
        mean_2=jnp.zeros((1, 1)),
    )

    return AVGState(
        rng=rng,
        eval_rng=rng,
        actor_state=actor_state,
        critic_state=critic_state,
        alpha=alpha,
        collector_state=collector_state,
        reward=init_norm_info,
        gamma=init_norm_info,
        G_return=init_norm_info,
        scaling_coef=jnp.ones((1, 1)),
    )


def compute_avg_td_target(
    actor_state: LoadedTrainState,
    critic_states: LoadedTrainState,
    critic_params: FrozenDict,
    rng: jax.Array,
    next_observations: jax.Array,
    dones: jax.Array,
    rewards: jax.Array,
    gamma: float,
    alpha: jax.Array,
    recurrent: bool,
    reward_scale: float,
) -> Tuple[jax.Array, jax.Array]:
    """AVG bellman target (no target network, uses current critic_params)."""
    rewards = rewards * reward_scale
    next_pi, _ = get_pi(
        actor_state=actor_state,
        actor_params=actor_state.params,
        obs=next_observations,
        done=dones,
        recurrent=recurrent,
    )
    sample_key, _ = jax.random.split(rng)
    next_actions, next_log_probs = next_pi.sample_and_log_prob(seed=sample_key)
    next_log_probs = next_log_probs.sum(-1, keepdims=True)
    q_target = jnp.min(
        predict_value(
            critic_state=critic_states,
            critic_params=critic_params,
            x=jnp.concatenate((next_observations, next_actions), axis=-1),
        ),
        axis=0,
    )
    target = jax.lax.stop_gradient(
        rewards + (1.0 - dones) * gamma * (q_target - alpha * next_log_probs),
    )
    return target, next_log_probs


@partial(jax.jit, static_argnames=["recurrent", "gamma", "reward_scale"])
def value_loss_function(
    critic_params: FrozenDict,
    critic_states: LoadedTrainState,
    rng: jax.Array,
    actor_state: LoadedTrainState,
    actions: jax.Array,
    observations: jax.Array,
    next_observations: jax.Array,
    dones: jax.Array,
    rewards: jax.Array,
    gamma: float,
    alpha: jax.Array,
    recurrent: bool,
    scaling_coef: jax.Array,
    reward_scale: float = 5.0,  # Add reward scaling factor here
    target_q_override: Optional[jax.Array] = None,
    log_probs_override: Optional[jax.Array] = None,
) -> Tuple[jax.Array, ValueAuxiliaries]:
    """
    Compute the value loss for the critic networks.

    Args:
        critic_params (FrozenDict): Parameters of the critic networks.
        critic_states (LoadedTrainState): Critic train states.
        rng (jax.Array): Random number generator key.
        actor_state (LoadedTrainState): Actor train state.
        actions (jax.Array): Actions taken.
        observations (jax.Array): Current observations.
        next_observations (jax.Array): Next observations.
        dones (jax.Array): Done flags.
        rewards (jax.Array): Rewards received.
        gamma (float): Discount factor.
        alpha (jax.Array): Temperature parameter.
        recurrent (bool): Whether the model is recurrent.
        reward_scale (float): Reward scaling factor.

    Returns:
        Tuple[jax.Array, Dict[str, jax.Array]]: Loss and auxiliary metrics.
    """
    q_pred = jnp.min(
        predict_value(
            critic_state=critic_states,
            critic_params=critic_params,
            x=jnp.concatenate((observations, actions), axis=-1),
        ),
        axis=0,
    )

    if target_q_override is not None:
        target_q = target_q_override
        next_log_probs = (
            log_probs_override
            if log_probs_override is not None
            else jnp.zeros_like(target_q)
        )
    else:
        target_q, next_log_probs = compute_avg_td_target(
            actor_state,
            critic_states,
            critic_params,
            rng,
            next_observations,
            dones,
            rewards,
            gamma,
            alpha,
            recurrent,
            reward_scale,
        )

    assert target_q.shape == q_pred.shape, f"{target_q.shape} != {q_pred.shape}"

    delta = q_pred - target_q
    scaled_delta = delta / scaling_coef
    assert scaled_delta.shape == delta.shape, f"{scaled_delta.shape} != {delta.shape}"
    total_loss = jnp.mean(scaled_delta**2)
    return total_loss, ValueAuxiliaries(
        critic_loss=total_loss,
        q_pred=q_pred.mean().flatten(),
        target_q=target_q.mean().flatten(),
        log_probs=next_log_probs.mean().flatten(),
        scaling_coef=scaling_coef.mean().flatten(),
    )


EPS = 1e-12


@partial(
    jax.jit,
    static_argnames=["recurrent", "obs_preprocessor", "policy_action_transform"],
)
def policy_loss_function(
    actor_params: FrozenDict,
    actor_state: LoadedTrainState,
    critic_states: LoadedTrainState,
    observations: jax.Array,
    dones: Optional[jax.Array],
    recurrent: bool,
    alpha: jax.Array,
    rng: jax.random.PRNGKey,
    raw_observations: Optional[jax.Array] = None,
    a_expert_precomputed: Optional[jax.Array] = None,
    obs_preprocessor: Optional[Callable] = None,
    policy_action_transform: Optional[Callable] = None,
) -> Tuple[jax.Array, PolicyAuxiliaries]:
    """
    Compute the policy loss for the actor network.

    Args:
        actor_params (FrozenDict): Parameters of the actor network.
        actor_state (LoadedTrainState): Actor train state.
        critic_states (LoadedTrainState): Critic train states.
        observations (jax.Array): Current observations.
        dones (Optional[jax.Array]): Done flags.
        recurrent (bool): Whether the model is recurrent.
        alpha (jax.Array): Temperature parameter.
        rng (jax.random.PRNGKey): Random number generator key.

    Returns:
        Tuple[jax.Array, Dict[str, jax.Array]]: Loss and auxiliary metrics.
    """
    obs_for_actor = (
        obs_preprocessor(observations) if obs_preprocessor is not None else observations
    )
    pi, _ = get_pi(
        actor_state=actor_state,
        actor_params=actor_params,
        obs=obs_for_actor,
        done=dones,
        recurrent=recurrent,
    )
    actions, log_probs = pi.sample_and_log_prob(seed=rng)

    _raw_obs = raw_observations if raw_observations is not None else observations
    q_input_actions = (
        policy_action_transform(actions, _raw_obs, a_expert_precomputed)
        if policy_action_transform is not None
        else actions
    )
    # Predict Q-values from critics
    q_pred = jnp.min(
        predict_value(
            critic_state=critic_states,
            critic_params=critic_states.params,
            x=jnp.hstack((observations, q_input_actions)),
        ),
        axis=0,
    )

    # q_pred: shape(n_envs,1) , squeeze is to remove the leading dimension of ensemble-critic

    log_probs = log_probs.sum(
        -1, keepdims=True
    )  # Shape (B,n_actions) to shape (n_envs,1)

    assert log_probs.shape == q_pred.shape, f"{log_probs.shape} != {q_pred.shape}"
    loss = (alpha * log_probs - q_pred).mean()

    return loss, PolicyAuxiliaries(
        policy_loss=loss, log_pi=log_probs.mean(), q_min=q_pred.mean()
    )


@partial(
    jax.jit,
    static_argnames=["target_entropy"],
)
def temperature_loss_function(
    log_alpha_params: FrozenDict,
    corrected_log_probs: jax.Array,
    target_entropy: float,
) -> Tuple[jax.Array, TemperatureAuxiliaries]:
    """
    Compute the loss for the temperature parameter (alpha).

    Args:
        log_alpha_params (FrozenDict): Logarithm of alpha parameters.
        corrected_log_probs (jax.Array): Log probabilities of actions.
        target_entropy (float): Target entropy value.

    Returns:
        Tuple[jax.Array, Dict[str, Any]]: Loss and auxiliary metrics.
    """
    log_alpha = log_alpha_params["log_alpha"]
    alpha = jnp.exp(log_alpha)

    loss = (
        -1.0
        * (
            log_alpha * jax.lax.stop_gradient(corrected_log_probs + target_entropy)
        ).mean()
    )

    return loss, TemperatureAuxiliaries(
        alpha_loss=loss, alpha=alpha, log_alpha=log_alpha
    )


def update_value_functions(
    agent_state: AVGState,
    observations: jax.Array,
    actions: jax.Array,
    next_observations: jax.Array,
    dones: Optional[jax.Array],
    recurrent: bool,
    rewards: jax.Array,
    gamma: float,
    reward_scale: float = 1.0,  # Add reward scaling factor here
    target_modifier: Optional[Callable] = None,
    extension_stack: Optional[ExtensionStack] = None,
    total_timesteps: int = 1,
) -> Tuple[AVGState, Dict[str, Any]]:
    """
    Update the critic networks using the value loss.

    Args:
        agent_state (AVGState): Current SAC agent state.
        observations (jax.Array): Current observations.
        actions (jax.Array): Actions taken.
        next_observations (jax.Array): Next observations.
        dones (Optional[jax.Array]): Done flags.
        recurrent (bool): Whether the model is recurrent.
        rewards (jax.Array): Rewards received.
        gamma (float): Discount factor.
        reward_scale (float): Reward scaling factor.

    Returns:
        Tuple[AVGState, Dict[str, Any]]: Updated agent state and auxiliary metrics.
    """
    value_loss_key, _ = jax.random.split(agent_state.rng, 2)
    log_alpha = agent_state.alpha.params["log_alpha"]
    alpha = jnp.exp(log_alpha)
    has_stack = extension_stack is not None and bool(extension_stack.extensions)

    target_q_override = None
    log_probs_override = None
    if target_modifier is not None or has_stack:
        target_q, log_probs = compute_avg_td_target(
            agent_state.actor_state,
            agent_state.critic_state,
            agent_state.critic_state.params,
            value_loss_key,
            next_observations,
            dones,
            rewards,
            gamma,
            alpha,
            recurrent,
            reward_scale,
        )
        if target_modifier is not None:
            q_preds_for_modifier = predict_value(
                critic_state=agent_state.critic_state,
                critic_params=agent_state.critic_state.params,
                x=jnp.concatenate((observations, actions), axis=-1),
            )
            target_q, _, _ = target_modifier(
                target_q,
                agent_state,
                observations,
                actions,
                next_observations,
                dones,
                gamma,
                value_loss_key,
                q_preds_for_modifier,
            )
        if has_stack:
            assert extension_stack is not None
            _tgt_batch = {
                "observations": observations,
                "actions": actions,
                "next_observations": next_observations,
                "rewards": rewards,
                "dones": dones,
                "gamma": gamma,
                "reward_scale": reward_scale,
            }
            target_q = extension_stack.fold_on_target(
                agent_state,
                _tgt_batch,
                target_q,
                agent_state.collector_state.timestep,
                value_loss_key,
                total_timesteps,
            )
        target_q_override = jax.lax.stop_gradient(target_q)
        log_probs_override = log_probs

    def _critic_loss(params):
        loss, core_aux = value_loss_function(
            params,
            agent_state.critic_state,
            value_loss_key,
            agent_state.actor_state,
            actions,
            observations,
            next_observations,
            dones,
            rewards,
            gamma,
            alpha,
            recurrent,
            agent_state.scaling_coef,
            reward_scale,
            target_q_override,
            log_probs_override,
        )
        if has_stack:
            assert extension_stack is not None
            _cl_batch = {
                "observations": observations,
                "actions": actions,
                "critic_params": params,
                "critic_state": agent_state.critic_state,
            }
            loss = loss + extension_stack.fold_critic_loss(
                agent_state,
                _cl_batch,
                agent_state.collector_state.timestep,
                value_loss_key,
                total_timesteps,
            )
        return loss, core_aux

    # Call the value loss function with reward scaling applied
    (loss, aux), grads = jax.value_and_grad(_critic_loss, has_aux=True)(
        agent_state.critic_state.params,
    )
    updated_critic_state = agent_state.critic_state.apply_gradients(grads=grads)
    agent_state = agent_state.replace(
        # rng=rng, need to keep the same RNG to keep the same action sampled, \
        # next actions are still used with a different seed than action
        critic_state=updated_critic_state,
    )
    return agent_state, aux


@partial(
    jax.jit,
    static_argnames=[
        "recurrent",
        "obs_preprocessor",
        "policy_action_transform",
        "extension_stack",
        "total_timesteps",
    ],
)
def update_policy(
    agent_state: AVGState,
    actions: jax.Array,
    log_probs: jax.Array,
    observations: jax.Array,
    done: Optional[jax.Array],
    recurrent: bool,
    raw_observations: Optional[jax.Array] = None,
    a_expert_precomputed: Optional[jax.Array] = None,
    obs_preprocessor: Optional[Callable] = None,
    policy_action_transform: Optional[Callable] = None,
    extension_stack: Optional[ExtensionStack] = None,
    total_timesteps: int = 1,
) -> Tuple[AVGState, Dict[str, Any]]:
    """
    Update the actor network using the policy loss.

    Args:
        agent_state (AVGState): Current SAC agent state.
        observations (jax.Array): Current observations.
        done (Optional[jax.Array]): Done flags.
        recurrent (bool): Whether the model is recurrent.

    Returns:
        Tuple[AVGState, Dict[str, Any]]: Updated agent state and auxiliary metrics.
    """
    rng, policy_key, _ = jax.random.split(agent_state.rng, 3)

    log_alpha = agent_state.alpha.params["log_alpha"]
    alpha = jnp.exp(log_alpha)
    has_stack = extension_stack is not None and bool(extension_stack.extensions)

    def _actor_loss(params):
        loss, core_aux = policy_loss_function(
            params,
            agent_state.actor_state,
            agent_state.critic_state,
            observations,
            done,
            recurrent,
            alpha,
            policy_key,
            raw_observations=raw_observations,
            a_expert_precomputed=a_expert_precomputed,
            obs_preprocessor=obs_preprocessor,
            policy_action_transform=policy_action_transform,
        )
        if has_stack:
            assert extension_stack is not None
            _al_batch = {
                "observations": observations,
                "actor_params": params,
                "actor_state": agent_state.actor_state,
            }
            loss = loss + extension_stack.fold_actor_loss(
                agent_state,
                _al_batch,
                agent_state.collector_state.timestep,
                policy_key,
                total_timesteps,
            )
        return loss, core_aux

    (loss, aux), grads = jax.value_and_grad(_actor_loss, has_aux=True)(
        agent_state.actor_state.params,
    )

    updated_actor_state = agent_state.actor_state.apply_gradients(grads=grads)
    agent_state = agent_state.replace(
        rng=rng,
        actor_state=updated_actor_state,
    )
    return agent_state, aux


# TODO(2026-05-27): ``update_temperature`` is defined here but
# NEVER called from the active path. ``create_alpha_train_state``
# initialises ``agent_state.alpha`` (default alpha=1.0) and
# ``update_agent`` reads alpha from it, but no caller ever runs the
# alpha gradient update. Net effect: AVG runs with alpha frozen at
# init forever. This mirrors the pattern that turned out to be a real
# bug in PPO (``update_agent`` defined-but-not-called → the active
# ``body_fn`` did the wrong thing). Two interpretations:
#   (a) intentional — Vasan 2024 AVG uses a fixed entropy bonus, in
#       which case ``temperature_loss_function`` and
#       ``update_temperature`` should be deleted and
#       ``create_alpha_train_state`` simplified to a fixed scalar.
#   (b) bug — alpha was meant to be tuned via the dual-gradient
#       (SAC/ASAC/REDQ pattern), and the call was forgotten.
# Decision pending; pilot results suggest AVG behaves reasonably with
# alpha=init, so (a) is plausible. Surfacing here so the next AVG
# pass settles it.
@partial(
    jax.jit,
    static_argnames=["target_entropy", "recurrent"],
)
def update_temperature(
    agent_state: AVGState,
    observations: jax.Array,
    dones: Optional[jax.Array],
    target_entropy: float,
    recurrent: bool,
) -> Tuple[AVGState, Dict[str, Any]]:
    """
    Update the temperature parameter (alpha) using the alpha loss.

    Args:
        agent_state (AVGState): Current SAC agent state.
        observations (jax.Array): Current observations.
        dones (Optional[jax.Array]): Done flags.
        target_entropy (float): Target entropy value.
        recurrent (bool): Whether the model is recurrent.

    Returns:
        Tuple[AVGState, Dict[str, Any]]: Updated agent state and auxiliary metrics.
    """
    loss_fn = jax.value_and_grad(temperature_loss_function, has_aux=True)

    pi, _ = get_pi(
        actor_state=agent_state.actor_state,
        actor_params=agent_state.actor_state.params,
        obs=observations,
        done=dones,
        recurrent=recurrent,
    )
    rng, sample_key = jax.random.split(agent_state.rng)
    _, log_probs = pi.sample_and_log_prob(seed=sample_key)

    (loss, aux), grads = loss_fn(
        agent_state.alpha.params,
        log_probs.sum(-1),
        target_entropy,
    )

    new_alpha_state = agent_state.alpha.apply_gradients(grads=grads)
    agent_state = agent_state.replace(
        rng=rng,
        alpha=new_alpha_state,
    )
    return agent_state, jax.lax.stop_gradient(aux)


@partial(
    jax.jit,
    static_argnames=[
        "recurrent",
        "gamma",
        "action_dim",
        "reward_scale",
        "num_critic_updates",
        "expert_policy",
        "target_modifier",
        "obs_preprocessor",
        "policy_action_transform",
        "extension_stack",
        "total_timesteps",
    ],
)
def update_agent(
    agent_state: AVGState,
    _: Any,
    recurrent: bool,
    gamma: float,
    action_dim: int,
    num_critic_updates: int = 1,
    reward_scale: float = 5.0,
    expert_policy: Optional[Callable] = None,
    target_modifier: Optional[Callable] = None,
    obs_preprocessor: Optional[Callable] = None,
    policy_action_transform: Optional[Callable] = None,
    extension_stack: Optional[ExtensionStack] = None,
    total_timesteps: int = 1,
) -> Tuple[AVGState, AuxiliaryLogs]:
    """
    Update the SAC agent, including critic, actor, and temperature updates.

    Args:
        agent_state (AVGState): Current SAC agent state.
        _ (Any): Placeholder for scan compatibility.
        recurrent (bool): Whether the model is recurrent.
        gamma (float): Discount factor.
        action_dim (int): Action dimensionality.
        tau (float): Soft update coefficient.
        num_critic_updates (int): Number of critic updates per step.
        reward_scale (float): Reward scaling factor.

    Returns:
        Tuple[AVGState, None]: Updated agent state.
    """
    transition = agent_state.collector_state.rollout
    done = jnp.logical_or(transition.terminated, transition.truncated)  # type: ignore[union-attr]

    raw_observations = getattr(transition, "raw_obs", None)
    a_expert_precomputed = None
    if expert_policy is not None and policy_action_transform is not None:
        _raw = raw_observations if raw_observations is not None else transition.obs  # type: ignore[union-attr]
        a_expert_precomputed = jax.lax.stop_gradient(expert_policy(_raw))

    # Update Q functions
    def critic_update_step(carry, _):
        agent_state = carry

        agent_state, aux_value = update_value_functions(
            observations=transition.obs,
            actions=transition.action,
            next_observations=transition.next_obs,
            dones=done,
            agent_state=agent_state,
            recurrent=recurrent,
            rewards=transition.reward,
            gamma=gamma,
            reward_scale=reward_scale,
            target_modifier=target_modifier,
            extension_stack=extension_stack,
            total_timesteps=total_timesteps,
        )

        return agent_state, aux_value

    agent_state_critic, aux_value = jax.lax.scan(
        critic_update_step,
        agent_state,
        None,
        length=num_critic_updates,
    )

    # Update policy
    agent_state_policy, aux_policy = update_policy(
        agent_state=agent_state,
        actions=transition.action,  # type: ignore[union-attr]
        log_probs=transition.log_prob,  # type: ignore[union-attr]
        observations=transition.obs,  # type: ignore[union-attr]
        done=done,
        recurrent=recurrent,
        raw_observations=raw_observations,
        a_expert_precomputed=a_expert_precomputed,
        obs_preprocessor=obs_preprocessor,
        policy_action_transform=policy_action_transform,
        extension_stack=extension_stack,
        total_timesteps=total_timesteps,
    )
    collector_state = agent_state.collector_state.replace(
        num_update=agent_state.collector_state.num_update + 1
    )
    agent_state = agent_state.replace(
        actor_state=agent_state_policy.actor_state,
        critic_state=agent_state_critic.critic_state,
        rng=agent_state_policy.rng,
        collector_state=collector_state,
    )

    aux = AuxiliaryLogs(
        temperature=TemperatureAuxiliaries(
            jnp.nan,
            jnp.exp(agent_state.alpha.params["log_alpha"]),
            agent_state.alpha.params["log_alpha"],
        ),
        policy=aux_policy,
        value=ValueAuxiliaries(
            **{key: val.flatten() for key, val in to_state_dict(aux_value).items()}
        ),
    )
    return agent_state, aux


def flatten_dict(dict: Dict) -> Dict:
    return_dict = {}
    for key, val in dict.items():
        if isinstance(val, Dict):
            for subkey, subval in val.items():
                return_dict[f"{key}/{subkey}"] = subval
        else:
            return_dict[key] = val
    return return_dict


def prepare_metrics(aux):
    log_metrics = flatten_dict(to_state_dict(aux))
    return {key: val for (key, val) in log_metrics.items() if not (jnp.isnan(val))}


def no_op(x, *args):
    return x


def no_op_none(*args, **kwargs):
    return None


def squeeze_dim_0(x):
    return x.squeeze(0)


def get_nan(x):
    return jnp.nan * x


def update_AVG_values(
    agent_state: AVGState, rollout: Transition, agent_config: AVGConfig
) -> AVGState:
    log_alpha = agent_state.alpha.params["log_alpha"]
    alpha = jnp.exp(log_alpha)

    r_ent = rollout.reward - alpha * jax.lax.stop_gradient(rollout.log_prob).sum(
        -1, keepdims=True
    )

    reward = agent_state.reward.replace(value=r_ent)

    gamma = agent_state.gamma.replace(
        value=agent_config.gamma * (1 - rollout.terminated)
    )

    new_G = agent_state.G_return.value + r_ent

    temp_G_value = jax.vmap(jax.lax.cond, in_axes=(0, None, None, 0))(
        rollout.terminated.astype("int8").squeeze(-1), no_op, get_nan, new_G
    )  # set G_return.value to nan if not terminal, for compute_td_error_scaling

    scaling_coef, reward, gamma, G_return = compute_td_error_scaling(
        reward, gamma, G_return=agent_state.G_return.replace(value=temp_G_value)
    )

    G_value = jax.vmap(jax.lax.cond, in_axes=(0, None, None, 0))(
        rollout.terminated.astype("int8").squeeze(-1), jnp.zeros_like, no_op, new_G
    )  # either revert to new_G (from nan) to keep on accumulating, or reset to 0
    G_return = G_return.replace(value=G_value)
    agent_state = agent_state.replace(
        reward=reward, gamma=gamma, G_return=G_return, scaling_coef=scaling_coef
    )

    return agent_state


@partial(
    jax.jit, static_argnames=["run_and_log", "no_op_none", "log_frequency", "env_args"]
)
def log_function(
    agent_state,
    log_frequency,
    timestep,
    total_timesteps,
    aux,
    run_and_log,
    no_op_none,
    env_args,
    index,
):
    _, eval_rng = jax.random.split(agent_state.eval_rng)
    agent_state = agent_state.replace(eval_rng=eval_rng)
    log_flag = timestep - (agent_state.n_logs * log_frequency) >= log_frequency

    agent_state = agent_state.replace(
        n_logs=jax.lax.select(log_flag, agent_state.n_logs + 1, agent_state.n_logs)
    )
    flag = jnp.logical_or(
        jnp.logical_and(log_flag, timestep > 1),
        timestep >= (total_timesteps - env_args.n_envs),
    )

    jax.lax.cond(flag, run_and_log, no_op_none, agent_state, aux, index)
    del aux
    return agent_state


@partial(
    jax.jit,
    static_argnames=[
        "env_args",
        "mode",
        "recurrent",
        "log_frequency",
        "num_episode_test",
        "log_fn",
        "log",
        "verbose",
        "action_dim",
        "lstm_hidden_size",
        "agent_config",
        "total_timesteps",
        "expert_policy",
        "action_pipeline",
        "eval_action_transform",
        "target_modifier",
        "obs_preprocessor",
        "policy_action_transform",
        "extension_stack",
    ],
)
def training_iteration(
    agent_state: AVGState,
    _: Any,
    env_args: EnvironmentConfig,
    mode: str,
    recurrent: bool,
    agent_config: AVGConfig,
    action_dim: int,
    total_timesteps: int,
    lstm_hidden_size: Optional[int] = None,
    log_frequency: int = 1000,
    num_episode_test: int = 10,
    log_fn: Optional[Callable] = None,
    index: Optional[int] = None,
    log: bool = False,
    verbose: bool = False,
    expert_policy: Optional[Callable] = None,
    action_pipeline: Optional[Callable] = None,
    eval_action_transform: Optional[Callable] = None,
    target_modifier: Optional[Callable] = None,
    obs_preprocessor: Optional[Callable] = None,
    policy_action_transform: Optional[Callable] = None,
    extension_stack: Optional[ExtensionStack] = None,
) -> tuple[AVGState, None]:
    """
    Perform one training iteration, including experience collection and agent updates.

    Args:
        agent_state (AVGState): Current SAC agent state.
        _ (Any): Placeholder for scan compatibility.
        env_args (EnvironmentConfig): Environment configuration.
        mode (str): Environment mode ("gymnax" or "brax").
        recurrent (bool): Whether the model is recurrent.
        agent_config (SACConfig): SAC agent configuration.
        action_dim (int): Action dimensionality.
        lstm_hidden_size (Optional[int]): LSTM hidden size for recurrent models.
        log_frequency (int): Frequency of logging and evaluation.
        num_episode_test (int): Number of episodes for evaluation.

    Returns:
        Tuple[AVGState, None]: Updated agent state.
    """

    timestep = agent_state.collector_state.timestep
    uniform = should_use_uniform_sampling(timestep, agent_config.learning_starts)

    collect_scan_fn = partial(
        collect_experience,
        recurrent=recurrent,
        mode=mode,
        env_args=env_args,
        uniform=uniform,
        action_pipeline=action_pipeline,
    )
    rng = agent_state.rng
    agent_state, rollout = jax.lax.scan(collect_scan_fn, agent_state, xs=None, length=1)

    # Gap A: expose the freshly collected ``(T=1, n_envs, ...)`` rollout
    # on ``agent_state.last_rollout`` BEFORE the T-axis is squeezed, so
    # measurement extensions see the same ``(T, n_envs, ...)`` layout
    # as the other on-policy agents (PPO / PQN / APO). Off by default —
    # see :attr:`BaseAgentState.last_rollout`.
    if getattr(agent_config, "expose_recent_rollout", False):
        agent_state = agent_state.replace(last_rollout=rollout)

    rollout = jax.tree.map(
        squeeze_dim_0, rollout
    )  # Remove first dim as we only have one transition
    # jax.debug.print("before {x}", x=timestep)
    collector_state = agent_state.collector_state.replace(rollout=rollout)
    agent_state = agent_state.replace(collector_state=collector_state)
    agent_state = update_AVG_values(agent_state, rollout, agent_config)
    timestep = agent_state.collector_state.timestep
    # jax.debug.print("after {x}", x=timestep)
    agent_state = agent_state.replace(rng=rng)

    def do_update(agent_state):
        update_scan_fn = partial(
            update_agent,
            recurrent=recurrent,
            gamma=agent_config.gamma,
            action_dim=action_dim,
            reward_scale=agent_config.reward_scale,
            expert_policy=expert_policy,
            target_modifier=target_modifier,
            obs_preprocessor=obs_preprocessor,
            policy_action_transform=policy_action_transform,
            extension_stack=extension_stack,
            total_timesteps=total_timesteps,
        )
        agent_state, aux = jax.lax.scan(update_scan_fn, agent_state, xs=None, length=1)
        aux = aux.replace(
            value=ValueAuxiliaries(
                **{key: val.flatten() for key, val in to_state_dict(aux.value).items()}
            )
        )

        # Extension post_update — folded once per training_iteration.
        # Empty stack ⇒ identity.
        if extension_stack is not None:
            _pu_rng, _pu_rng2 = jax.random.split(agent_state.rng)
            agent_state = agent_state.replace(rng=_pu_rng2)
            agent_state = extension_stack.fold_post_update(
                agent_state,
                agent_state.collector_state.timestep,
                _pu_rng,
                total_timesteps,
            )
        return agent_state, aux

    def fill_with_nan(dataclass):
        """
        Recursively fills all fields of a dataclass with jnp.nan.
        """
        nan = jnp.ones(1) * jnp.nan
        dict = {}
        for field in fields(dataclass):
            sub_dataclass = field.type
            if hasattr(
                sub_dataclass, "__dataclass_fields__"
            ):  # Check if the field is another dataclass
                dict[field.name] = fill_with_nan(sub_dataclass)
            else:
                dict[field.name] = nan
        return dataclass(**dict)

    def skip_update(agent_state):
        return agent_state, fill_with_nan(AuxiliaryLogs)

    agent_state, aux = jax.lax.cond(
        timestep >= agent_config.learning_starts,
        do_update,
        skip_update,
        operand=agent_state,
    )

    _extra_eval = compose_eval_metrics(None, extension_stack, total_timesteps)
    agent_state, metrics_to_log = evaluate_and_log(
        agent_state,
        aux,
        index,
        mode,
        env_args,
        num_episode_test,
        recurrent,
        lstm_hidden_size,
        log,
        verbose,
        log_fn,
        log_frequency,
        total_timesteps,
        expert_policy=expert_policy,
        eval_action_transform=eval_action_transform,
        extra_eval_metrics=_extra_eval,
    )

    jax.clear_caches()
    return agent_state, metrics_to_log


def profile_memory(timestep):
    jax.profiler.save_device_memory_profile(f"memory{timestep}.prof")


def safe_get_env_var(var_name: str, default: Optional[str] = None) -> Optional[str]:
    """
    Safely retrieve an environment variable.

    Args:
        var_name (str): The name of the environment variable.
        default (Optional[str]): Default value if the variable is not set.

    Returns:
        Optional[str]: The value of the environment variable or default.
    """
    value = os.environ.get(var_name)
    if value is None:
        return default
    return value


def make_train(
    env_args: EnvironmentConfig,
    actor_optimizer_args: OptimizerConfig,
    critic_optimizer_args: OptimizerConfig,
    network_args: NetworkConfig,
    agent_config: AVGConfig,
    alpha_args: AlphaConfig,
    total_timesteps: int,
    num_episode_test: int,
    run_ids: Optional[Sequence[str]] = None,
    logging_config: Optional[LoggingConfig] = None,
    expert_policy: Optional[Callable] = None,
    pid_actor_config: Optional[PIDActorConfig] = None,
    action_pipeline: Optional[Callable] = None,
    eval_action_transform: Optional[Callable] = None,
    target_modifier: Optional[Callable] = None,
    obs_preprocessor: Optional[Callable] = None,
    policy_action_transform: Optional[Callable] = None,
    extensions: Sequence = (),
):
    """
    Create the training function for the SAC agent.

    Args:
        env_args (EnvironmentConfig): Environment configuration.
        optimizer_args (OptimizerConfig): Optimizer configuration.
        network_args (NetworkConfig): Network configuration.
        agent_config (SACConfig): SAC agent configuration.
        alpha_args (AlphaConfig): Alpha configuration.
        total_timesteps (int): Total timesteps for training.
        num_episode_test (int): Number of episodes for evaluation during training.

    Returns:
        Callable: JIT-compiled training function.
    """
    mode = "gymnax" if check_env_is_gymnax(env_args.env) else "brax"
    log = logging_config is not None
    log_fn = partial(vmap_log, run_ids=run_ids, logging_config=logging_config)

    # Start async logging if logging is enabled
    if logging_config is not None:
        start_async_logging()

    extension_stack = ExtensionStack(extensions) if extensions else None

    @train_jit
    def train(key, index: Optional[int] = None):
        """Train the SAC agent."""

        agent_state = init_AVG(
            key=key,
            env_args=env_args,
            actor_optimizer_args=actor_optimizer_args,
            critic_optimizer_args=critic_optimizer_args,
            network_args=network_args,
            alpha_args=alpha_args,
            num_critics=agent_config.num_critics,
            pid_actor_config=pid_actor_config,
        )

        if extension_stack is not None:
            _ext_key, _pre_key = jax.random.split(key)
            agent_state = extension_stack.fold_init_states(agent_state, _ext_key)
            agent_state = extension_stack.fold_pretrain(
                agent_state, jnp.asarray(0), _pre_key, total_timesteps
            )

        num_updates = total_timesteps  # // env_args.n_envs
        _, action_shape = get_state_action_shapes(env_args.env)

        # Gap A: pre-allocate the ``last_rollout`` placeholder so the
        # scan-carry pytree structure is stable from iteration zero.
        # AVG collects ``length=1`` per iteration, so the placeholder
        # carries a leading ``T=1`` axis (matching the pre-squeeze
        # rollout the training_iteration stashes).
        if getattr(agent_config, "expose_recent_rollout", False):
            _trace_scan = partial(
                collect_experience,
                recurrent=network_args.lstm_hidden_size is not None,
                mode=mode,
                env_args=env_args,
                action_pipeline=action_pipeline,
            )
            _, _trans_abs = jax.eval_shape(
                lambda st: jax.lax.scan(_trace_scan, st, xs=None, length=1),
                agent_state,
            )
            agent_state = agent_state.replace(
                last_rollout=zeros_like_abstract_pytree(_trans_abs)
            )

        training_iteration_scan_fn = partial(
            training_iteration,
            recurrent=network_args.lstm_hidden_size is not None,
            action_dim=action_shape[0],
            agent_config=agent_config,
            mode=mode,
            env_args=env_args,
            num_episode_test=num_episode_test,
            log_fn=log_fn,
            index=index,
            log=log,
            total_timesteps=total_timesteps,
            log_frequency=(
                logging_config.log_frequency if logging_config is not None else None
            ),
            expert_policy=expert_policy,
            action_pipeline=action_pipeline,
            eval_action_transform=eval_action_transform,
            target_modifier=target_modifier,
            obs_preprocessor=obs_preprocessor,
            policy_action_transform=policy_action_transform,
            extension_stack=extension_stack,
        )

        agent_state, metrics = jax.lax.scan(
            f=training_iteration_scan_fn,
            init=agent_state,
            xs=None,
            length=num_updates,
        )

        return agent_state, metrics

    return train
