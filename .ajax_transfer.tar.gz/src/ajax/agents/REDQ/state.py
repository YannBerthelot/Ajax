from flax import struct
from jax.tree_util import Partial as partial

from ajax.state import BaseAgentConfig, BaseAgentState, LoadedTrainState


@partial(struct.dataclass, kw_only=True)
class REDQState(BaseAgentState):
    """The agent properties to be carried over iterations of environment interaction and updates"""

    alpha: LoadedTrainState  # Temperature parameter


@partial(struct.dataclass, kw_only=True)
class REDQConfig(BaseAgentConfig):
    """The agent properties to be carried over iterations of environment interaction and updates"""

    gamma: float
    target_entropy: float
    tau: float = 0.005
    learning_starts: int = 100
    reward_scale: float = 5.0
    num_critics: int = 10
    subset_size: int = 2
    num_critic_updates: int = 20
    # SVGD-style function-space kernel repulsion coefficient on the
    # critic ensemble. 0.0 disables it (vanilla REDQ).
    repulsion_coef: float = 0.0
    # Recurrent (memory) training only; see ajax.agents.recurrent.
    burn_in: int = 8
    sequence_length: int = 16
    # R2D2 stored-state replay: read actor carries back from the buffer
    # instead of burning them in from zero (Kapturowski et al. 2019).
    stored_state: bool = False
