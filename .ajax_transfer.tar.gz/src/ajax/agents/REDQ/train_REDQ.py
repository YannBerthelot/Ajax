from collections.abc import Sequence
from dataclasses import fields
from math import floor
from typing import Any, Callable, Dict, Optional, Tuple

import jax
import jax.numpy as jnp
from flax import struct
from flax.core import FrozenDict
from flax.serialization import to_state_dict
from jax.tree_util import Partial as partial

from ajax.agents.cloning import (
    CloningConfig,
    compute_imitation_score,
    get_cloning_args,
    get_pre_trained_agent,
)
from ajax.agents.recurrent import (
    RecurrentCarries,
    sample_and_burnin_sequences,
    unsupported_recurrent_options,
)
from ajax.agents.REDQ.state import REDQConfig, REDQState
from ajax.agents.SAC.train_SAC import (
    TemperatureAuxiliaries,
    create_alpha_train_state,
    update_target_networks,
    update_temperature,
)
from ajax.buffers.utils import get_batch_from_buffer
from ajax.environments.interaction import (
    collect_experience,
    get_pi,
    get_pi_sequence,
    init_collector_state,
    should_use_uniform_sampling,
)
from ajax.environments.utils import check_env_is_gymnax, get_state_action_shapes
from ajax.extensions.base import ExtensionStack
from ajax.log import compose_eval_metrics, evaluate_and_log
from ajax.logging.wandb_logging import (
    LoggingConfig,
    start_async_logging,
    vmap_log,
)
from ajax.modules.pid_actor import PIDActorConfig
from ajax.networks.memory import flat_carry_dim, resolve_memory_config
from ajax.networks.networks import (
    get_initialized_actor_critic,
    predict_value,
    predict_value_sequence,
)
from ajax.perf_utils import final_aux_scan, train_jit
from ajax.state import (
    AlphaConfig,
    EnvironmentConfig,
    LoadedTrainState,
    NetworkConfig,
    OptimizerConfig,
    Transition,
)
from ajax.types import BufferType
from ajax.utils import get_one


@struct.dataclass
class PolicyAuxiliaries:
    policy_loss: jax.Array
    log_pi: jax.Array
    q_mean: jax.Array
    imitation_loss: jax.Array
    raw_loss: jax.Array


@struct.dataclass
class ValueAuxiliaries:
    critic_loss: jax.Array
    target_q: jax.Array
    log_probs: jax.Array
    repulsion_loss: jax.Array
    # Scale-free ensemble divergence diagnostics (stop_gradient'd). Unlike
    # repulsion_loss (self-normalised by the median-heuristic bandwidth, so
    # ~O(1) regardless of actual spread), these reveal whether the ensemble
    # genuinely diversified in function space.
    ensemble_q_std: jax.Array
    mean_pairwise_q_dist: jax.Array


def q_ensemble_divergence(q_preds: jax.Array) -> Tuple[jax.Array, jax.Array]:
    """Scale-free diagnostics for how spread out the critic ensemble is.

    Returns ``(ensemble_q_std, mean_pairwise_q_dist)``:
      * ensemble_q_std: std across the critic axis of the per-(s,a) Q
        prediction, averaged over the batch.
      * mean_pairwise_q_dist: mean L2 distance between the flattened
        per-critic Q-vectors over all off-diagonal pairs.

    Both are computed on stop_gradient'd predictions — they are telemetry
    only and must not contribute to the critic gradient.
    """
    q = jax.lax.stop_gradient(q_preds)
    n = q.shape[0]
    q_std = jnp.std(q, axis=0).mean()

    feats = q.reshape(n, -1)
    diffs = feats[:, None, :] - feats[None, :, :]
    dists = jnp.sqrt(jnp.sum(diffs**2, axis=-1) + 1e-12)
    off_diag_sum = dists.sum() - jnp.trace(dists)
    mean_pairwise = off_diag_sum / (n * (n - 1))
    return q_std, mean_pairwise


def q_kernel_repulsion(q_preds: jax.Array) -> jax.Array:
    """Function-space SVGD-style RBF kernel repulsion penalty.

    q_preds has shape ``(num_critics, batch, ...)``. Each ensemble member's
    output is flattened to a feature vector; pairwise squared distances feed
    an RBF kernel with the median-heuristic bandwidth (Liu & Wang 2017).
    The returned scalar is the mean kernel value over all pairs — minimising
    it pushes members apart in function space.

    The bandwidth `h` is stop_gradient'd so the kernel adapts to the current
    spread of predictions without contributing a confounding gradient term.
    """
    n = q_preds.shape[0]
    feats = q_preds.reshape(n, -1)
    diffs = feats[:, None, :] - feats[None, :, :]
    sq_dists = jnp.sum(diffs**2, axis=-1)
    # Median heuristic over off-diagonal pairs. n*(n-1) off-diagonal entries;
    # `jnp.median` over the full matrix is fine because diagonal zeros are
    # only n out of n^2 and the median is dominated by the off-diagonal mass
    # for n >= 4. The +1e-8 floor avoids divide-by-zero at init when all
    # critics happen to predict identical values.
    h = jax.lax.stop_gradient(
        jnp.median(sq_dists) / (jnp.log(jnp.asarray(n, dtype=feats.dtype)) + 1e-8)
        + 1e-8
    )
    kernel = jnp.exp(-sq_dists / h)
    return kernel.mean()


@struct.dataclass
class AuxiliaryLogs:
    temperature: TemperatureAuxiliaries
    policy: PolicyAuxiliaries
    value: ValueAuxiliaries


def init_REDQ(
    key: jax.Array,
    env_args: EnvironmentConfig,
    actor_optimizer_args: OptimizerConfig,
    critic_optimizer_args: OptimizerConfig,
    network_args: NetworkConfig,
    alpha_args: AlphaConfig,
    buffer: BufferType,
    number_of_critics: int,
    window_size: int = 10,
    stored_state: bool = False,
    pid_actor_config: Optional[PIDActorConfig] = None,
) -> REDQState:
    """
    Initialize the REDQ agent's state, including actor, critic, alpha, and collector states.

    Args:
        key (jax.Array): Random number generator key.
        env_args (EnvironmentConfig): Environment configuration.
        optimizer_args (OptimizerConfig): Optimizer configuration.
        network_args (NetworkConfig): Network configuration.
        alpha_args (AlphaConfig): Alpha configuration.
        buffer (BufferType): Replay buffer.

    Returns:
        REDQState: Initialized REDQ agent state.
    """
    (
        rng,
        init_key,
        collector_key,
    ) = jax.random.split(key, num=3)

    actor_state, critic_state = get_initialized_actor_critic(
        key=init_key,
        env_config=env_args,
        actor_optimizer_config=actor_optimizer_args,
        critic_optimizer_config=critic_optimizer_args,
        network_config=network_args,
        continuous=True,
        action_value=True,
        squash=True,
        num_critics=number_of_critics,
        pid_actor_config=pid_actor_config,
    )
    mode = "gymnax" if check_env_is_gymnax(env_args.env) else "brax"
    _actor_carry_dim = 0
    if stored_state:
        _mem = resolve_memory_config(network_args.memory, network_args.lstm_hidden_size)
        if _mem is not None:
            _actor_carry_dim = flat_carry_dim(_mem)
    collector_state = init_collector_state(
        collector_key,
        env_args=env_args,
        mode=mode,
        buffer=buffer,
        window_size=window_size,
        actor_carry_dim=_actor_carry_dim,
    )

    alpha = create_alpha_train_state(**to_state_dict(alpha_args))

    return REDQState(
        rng=rng,
        eval_rng=rng,
        actor_state=actor_state,
        critic_state=critic_state,
        alpha=alpha,
        collector_state=collector_state,
    )


def compute_redq_td_target(
    actor_state: LoadedTrainState,
    critic_states: LoadedTrainState,
    rng: jax.Array,
    next_observations: jax.Array,
    dones: jax.Array,
    rewards: jax.Array,
    gamma: float,
    alpha: jax.Array,
    recurrent: bool,
    subset_size: int,
    reward_scale: float,
    carries: Optional[RecurrentCarries] = None,
) -> Tuple[jax.Array, jax.Array]:
    """REDQ bellman target: min over a random subset of target critics.

    Returns (stop_gradient'd target, log_probs) for optional reuse.
    """
    rewards = rewards * reward_scale

    if recurrent:
        assert carries is not None  # narrowed: set by the recurrent path
        next_pi, _ = get_pi_sequence(
            actor_state=actor_state,
            actor_params=actor_state.params,
            obs=next_observations,
            resets=carries.next_resets,
            initial_hidden=carries.actor_next_hidden,
        )
    else:
        next_pi, _ = get_pi(
            actor_state=actor_state,
            actor_params=actor_state.params,
            obs=next_observations,
            done=dones,
            recurrent=recurrent,
        )
    sample_key, idx_sample_key = jax.random.split(rng)
    next_actions, log_probs = next_pi.sample_and_log_prob(seed=sample_key)
    log_probs = log_probs.sum(-1, keepdims=True)

    if recurrent:
        assert carries is not None  # narrowed: set by the recurrent path
        # The ensemble axis stays leading, so the subset sampling below is
        # identical in sequence mode.
        q_targets, _ = predict_value_sequence(
            critic_state=critic_states,
            critic_params=critic_states.target_params,
            x=jnp.concatenate((next_observations, next_actions), axis=-1),
            resets=carries.next_resets,
            initial_hidden=carries.target_critic_hidden,
        )
    else:
        q_targets = predict_value(
            critic_state=critic_states,
            critic_params=critic_states.target_params,
            x=jnp.concatenate((next_observations, next_actions), axis=-1),
        )
    sampled_indexes = jax.random.choice(
        idx_sample_key, q_targets.shape[0], shape=(subset_size,), replace=False
    )
    min_q_target = jnp.min(q_targets[sampled_indexes], axis=0)

    target = rewards + gamma * (1.0 - dones) * (min_q_target - alpha * log_probs)
    return jax.lax.stop_gradient(target), log_probs


@partial(jax.jit, static_argnames=["recurrent", "gamma", "reward_scale", "subset_size"])
def value_loss_function(
    critic_params: FrozenDict,
    critic_states: LoadedTrainState,
    rng: jax.Array,
    actor_state: LoadedTrainState,
    actions: jax.Array,
    observations: jax.Array,
    next_observations: jax.Array,
    dones: jax.Array,
    rewards: jax.Array,
    gamma: float,
    alpha: jax.Array,
    recurrent: bool,
    subset_size: int = 2,  # Number of critics to sample for target Q estimation
    reward_scale: float = 5.0,  # Add reward scaling factor here
    target_q_override: Optional[jax.Array] = None,
    log_probs_override: Optional[jax.Array] = None,
    repulsion_coef: float = 0.0,
    carries: Optional[RecurrentCarries] = None,
) -> Tuple[jax.Array, ValueAuxiliaries]:
    """
    Compute the value loss for the critic networks.

    Args:
        critic_params (FrozenDict): Parameters of the critic networks.
        critic_states (LoadedTrainState): Critic train states.
        rng (jax.Array): Random number generator key.
        actor_state (LoadedTrainState): Actor train state.
        actions (jax.Array): Actions taken.
        observations (jax.Array): Current observations.
        next_observations (jax.Array): Next observations.
        dones (jax.Array): Done flags.
        rewards (jax.Array): Rewards received.
        gamma (float): Discount factor.
        alpha (jax.Array): Temperature parameter.
        recurrent (bool): Whether the model is recurrent.
        reward_scale (float): Reward scaling factor.

    Returns:
        Tuple[jax.Array, Dict[str, jax.Array]]: Loss and auxiliary metrics.
    """
    # Predict Q-values from critics
    if recurrent:
        assert carries is not None  # narrowed: set by the recurrent path
        q_preds, _ = predict_value_sequence(
            critic_state=critic_states,
            critic_params=critic_params,
            x=jnp.concatenate((observations, jax.lax.stop_gradient(actions)), axis=-1),
            resets=carries.resets,
            initial_hidden=carries.critic_hidden,
        )
    else:
        q_preds = predict_value(
            critic_state=critic_states,
            critic_params=critic_params,
            x=jnp.concatenate((observations, jax.lax.stop_gradient(actions)), axis=-1),
        )

    # Target — use precomputed override (from target_modifier path) or compute inline
    if target_q_override is not None:
        target_q = target_q_override
        log_probs = (
            log_probs_override
            if log_probs_override is not None
            else jnp.zeros_like(target_q)
        )
    else:
        target_q, log_probs = compute_redq_td_target(
            actor_state,
            critic_states,
            rng,
            next_observations,
            dones,
            rewards,
            gamma,
            alpha,
            recurrent,
            subset_size,
            reward_scale,
            carries=carries,
        )

    bellman_loss = jnp.sum(
        jnp.mean((q_preds - target_q) ** 2, axis=tuple(range(1, q_preds.ndim)))
        / q_preds.ndim
    )

    repulsion = q_kernel_repulsion(q_preds)
    total_loss = bellman_loss + repulsion_coef * repulsion

    q_std, mean_pairwise_q_dist = q_ensemble_divergence(q_preds)

    return total_loss, ValueAuxiliaries(
        critic_loss=total_loss,
        target_q=target_q.mean().flatten(),
        log_probs=log_probs.mean().flatten(),
        repulsion_loss=repulsion.flatten(),
        ensemble_q_std=q_std.flatten(),
        mean_pairwise_q_dist=mean_pairwise_q_dist.flatten(),
    )


@partial(
    jax.jit,
    static_argnames=[
        "recurrent",
        "expert_policy",
        "distance_to_stable",
        "imitation_coef_offset",
        "obs_preprocessor",
        "policy_action_transform",
    ],
)
def policy_loss_function(
    actor_params: FrozenDict,
    actor_state: LoadedTrainState,
    critic_states: LoadedTrainState,
    observations: jax.Array,
    dones: Optional[jax.Array],
    recurrent: bool,
    alpha: jax.Array,
    rng: jax.random.PRNGKey,
    raw_observations: Optional[jax.Array] = None,
    expert_policy: Optional[Callable] = None,
    imitation_coef: float = 0.01,
    distance_to_stable: Callable = get_one,
    imitation_coef_offset: float = 1e-3,
    a_expert_precomputed: Optional[jax.Array] = None,
    obs_preprocessor: Optional[Callable] = None,
    policy_action_transform: Optional[Callable] = None,
    carries: Optional[RecurrentCarries] = None,
) -> Tuple[jax.Array, Tuple[PolicyAuxiliaries, jax.Array]]:
    """
    Compute the policy loss for the actor network.

    Args:
        actor_params (FrozenDict): Parameters of the actor network.
        actor_state (LoadedTrainState): Actor train state.
        critic_states (LoadedTrainState): Critic train states.
        observations (jax.Array): Current observations.
        dones (Optional[jax.Array]): Done flags.
        recurrent (bool): Whether the model is recurrent.
        alpha (jax.Array): Temperature parameter.
        rng (jax.random.PRNGKey): Random number generator key.

    Returns:
        Tuple[jax.Array, Dict[str, jax.Array]]: Loss and auxiliary metrics.
    """
    obs_for_actor = (
        obs_preprocessor(observations) if obs_preprocessor is not None else observations
    )
    if recurrent:
        assert carries is not None  # narrowed: set by the recurrent path
        pi, _ = get_pi_sequence(
            actor_state=actor_state,
            actor_params=actor_params,
            obs=obs_for_actor,
            resets=carries.resets,
            initial_hidden=carries.actor_hidden,
        )
    else:
        pi, _ = get_pi(
            actor_state=actor_state,
            actor_params=actor_params,
            obs=obs_for_actor,
            done=dones,
            recurrent=recurrent,
        )
    sample_key, rng = jax.random.split(rng)
    actions, log_probs = pi.sample_and_log_prob(seed=sample_key)

    _raw_obs = raw_observations if raw_observations is not None else observations
    q_input_actions = (
        policy_action_transform(actions, _raw_obs, a_expert_precomputed)
        if policy_action_transform is not None
        else actions
    )

    # Predict Q-values from critics
    if recurrent:
        assert carries is not None  # narrowed: set by the recurrent path
        q_preds, _ = predict_value_sequence(
            critic_state=critic_states,
            critic_params=critic_states.params,
            x=jnp.concatenate((observations, q_input_actions), axis=-1),
            resets=carries.resets,
            initial_hidden=carries.critic_hidden,
        )
    else:
        q_preds = predict_value(
            critic_state=critic_states,
            critic_params=critic_states.params,
            x=jnp.hstack((observations, q_input_actions)),
        )

    # Unpack and unsqueeze if needed
    q_min = jnp.mean(q_preds, axis=0)

    log_probs = log_probs.sum(-1, keepdims=True)
    imitation_loss = compute_imitation_score(
        pi,
        expert_policy,
        raw_observations,
        distance_to_stable,
        imitation_coef_offset,
        q_preds=q_min,
        q_expert=q_min,  # unused by compute_imitation_score
    ).mean()

    assert log_probs.shape == q_min.shape, f"{log_probs.shape} != {q_min.shape}"
    loss_actor = alpha * log_probs - q_min
    total_loss = (loss_actor + imitation_coef * imitation_loss).mean()

    return total_loss, (
        PolicyAuxiliaries(
            policy_loss=total_loss,
            log_pi=log_probs.mean(),
            q_mean=q_min.mean(),
            imitation_loss=imitation_loss,
            raw_loss=loss_actor.mean(),
        ),
        log_probs,
    )


def update_value_functions(
    agent_state: REDQState,
    observations: jax.Array,
    actions: jax.Array,
    next_observations: jax.Array,
    dones: Optional[jax.Array],
    recurrent: bool,
    rewards: jax.Array,
    gamma: float,
    subset_size: int,
    reward_scale: float = 1.0,  # Add reward scaling factor here
    target_modifier: Optional[Callable] = None,
    repulsion_coef: float = 0.0,
    extension_stack: Optional[ExtensionStack] = None,
    total_timesteps: int = 1,
    carries: Optional[RecurrentCarries] = None,
) -> Tuple[REDQState, Dict[str, Any]]:
    """
    Update the critic networks using the value loss.

    Args:
        agent_state (REDQState): Current REDQ agent state.
        observations (jax.Array): Current observations.
        actions (jax.Array): Actions taken.
        next_observations (jax.Array): Next observations.
        dones (Optional[jax.Array]): Done flags.
        recurrent (bool): Whether the model is recurrent.
        rewards (jax.Array): Rewards received.
        gamma (float): Discount factor.
        reward_scale (float): Reward scaling factor.

    Returns:
        Tuple[REDQState, Dict[str, Any]]: Updated agent state and auxiliary metrics.
    """
    value_loss_key, rng = jax.random.split(agent_state.rng)
    log_alpha = agent_state.alpha.params["log_alpha"]
    alpha = jnp.exp(log_alpha)

    # Compute base REDQ target (with subset sampling) + apply optional target_modifier
    target_q_override = None
    log_probs_override = None
    has_stack = extension_stack is not None and bool(extension_stack.extensions)
    if target_modifier is not None or has_stack:
        target_q, log_probs = compute_redq_td_target(
            agent_state.actor_state,
            agent_state.critic_state,
            value_loss_key,
            next_observations,
            dones,
            rewards * reward_scale,
            gamma,
            alpha,
            recurrent,
            subset_size,
            1.0,  # reward_scale already applied above
        )
        if target_modifier is not None:
            q_preds_for_modifier = predict_value(
                critic_state=agent_state.critic_state,
                critic_params=agent_state.critic_state.params,
                x=jnp.concatenate(
                    (observations, jax.lax.stop_gradient(actions)), axis=-1
                ),
            )
            target_q, _, _ = target_modifier(
                target_q,
                agent_state,
                observations,
                actions,
                next_observations,
                dones,
                gamma,
                value_loss_key,
                q_preds_for_modifier,
            )
        if has_stack:
            assert extension_stack is not None
            _tgt_batch = {
                "observations": observations,
                "actions": actions,
                "next_observations": next_observations,
                "rewards": rewards,
                "dones": dones,
                "gamma": gamma,
                "reward_scale": reward_scale,
            }
            target_q = extension_stack.fold_on_target(
                agent_state,
                _tgt_batch,
                target_q,
                agent_state.collector_state.timestep,
                value_loss_key,
                total_timesteps,
            )
        target_q_override = jax.lax.stop_gradient(target_q)
        log_probs_override = log_probs

    def _critic_loss(params):
        loss, core_aux = value_loss_function(
            params,
            agent_state.critic_state,
            value_loss_key,
            agent_state.actor_state,
            actions,
            observations,
            next_observations,
            dones,
            rewards,
            gamma,
            alpha,
            recurrent,
            subset_size,
            reward_scale,
            target_q_override,
            log_probs_override,
            repulsion_coef,
            carries=carries,
        )
        if has_stack:
            assert extension_stack is not None
            _cl_batch = {
                "observations": observations,
                "actions": actions,
                "critic_params": params,
                "critic_state": agent_state.critic_state,
            }
            loss = loss + extension_stack.fold_critic_loss(
                agent_state,
                _cl_batch,
                agent_state.collector_state.timestep,
                value_loss_key,
                total_timesteps,
            )
        return loss, core_aux

    (loss, aux), grads = jax.value_and_grad(_critic_loss, has_aux=True)(
        agent_state.critic_state.params,
    )

    updated_critic_state = agent_state.critic_state.apply_gradients(grads=grads)
    agent_state = agent_state.replace(
        rng=rng,
        critic_state=updated_critic_state,
    )
    return agent_state, aux


@partial(
    jax.jit,
    static_argnames=[
        "recurrent",
        "expert_policy",
        "distance_to_stable",
        "imitation_coef_offset",
        "obs_preprocessor",
        "policy_action_transform",
        "extension_stack",
        "total_timesteps",
    ],
)
def update_policy(
    agent_state: REDQState,
    observations: jax.Array,
    done: Optional[jax.Array],
    recurrent: bool,
    raw_observations: jax.Array,
    expert_policy: Optional[Callable] = None,
    imitation_coef: float = 1e-3,
    distance_to_stable: Callable = get_one,
    imitation_coef_offset: float = 1e-3,
    a_expert_precomputed: Optional[jax.Array] = None,
    obs_preprocessor: Optional[Callable] = None,
    policy_action_transform: Optional[Callable] = None,
    extension_stack: Optional[ExtensionStack] = None,
    total_timesteps: int = 1,
    carries: Optional[RecurrentCarries] = None,
) -> Tuple[REDQState, Any, jax.Array]:
    """
    Update the actor network using the policy loss.

    Args:
        agent_state (REDQState): Current REDQ agent state.
        observations (jax.Array): Current observations.
        done (Optional[jax.Array]): Done flags.
        recurrent (bool): Whether the model is recurrent.

    Returns:
        Tuple[REDQState, Dict[str, Any]]: Updated agent state and auxiliary metrics.
    """
    rng, policy_key = jax.random.split(agent_state.rng)
    log_alpha = agent_state.alpha.params["log_alpha"]
    alpha = jnp.exp(log_alpha)
    has_stack = extension_stack is not None and bool(extension_stack.extensions)

    def _actor_loss(params):
        loss, (core_aux, log_probs) = policy_loss_function(
            params,
            agent_state.actor_state,
            agent_state.critic_state,
            observations,
            done,
            recurrent,
            alpha,
            policy_key,
            raw_observations=raw_observations,
            expert_policy=expert_policy,
            imitation_coef=imitation_coef,
            distance_to_stable=distance_to_stable,
            imitation_coef_offset=imitation_coef_offset,
            a_expert_precomputed=a_expert_precomputed,
            obs_preprocessor=obs_preprocessor,
            policy_action_transform=policy_action_transform,
            carries=carries,
        )
        if has_stack:
            assert extension_stack is not None
            _al_batch = {
                "observations": observations,
                "actor_params": params,
                "actor_state": agent_state.actor_state,
            }
            loss = loss + extension_stack.fold_actor_loss(
                agent_state,
                _al_batch,
                agent_state.collector_state.timestep,
                policy_key,
                total_timesteps,
            )
        return loss, (core_aux, log_probs)

    (loss, (aux, log_probs)), grads = jax.value_and_grad(_actor_loss, has_aux=True)(
        agent_state.actor_state.params,
    )

    updated_actor_state = agent_state.actor_state.apply_gradients(grads=grads)
    agent_state = agent_state.replace(
        rng=rng,
        actor_state=updated_actor_state,
    )
    return agent_state, aux, log_probs


@partial(
    jax.jit,
    static_argnames=[
        "recurrent",
        "buffer",
        "gamma",
        "tau",
        "action_dim",
        "num_critic_updates",
        "reward_scale",
        "target_update_frequency",
        "transition_mix_fraction",
        "expert_policy",
        "imitation_coef",
        "distance_to_stable",
        "imitation_coef_offset",
        "subset_size",
        "target_modifier",
        "obs_preprocessor",
        "policy_action_transform",
        "repulsion_coef",
        "extension_stack",
        "total_timesteps",
        "burn_in",
        "sequence_length",
        "stored_state",
    ],
)
def update_agent(
    agent_state: REDQState,
    _: Any,
    buffer: BufferType,
    recurrent: bool,
    gamma: float,
    action_dim: int,
    tau: float,
    num_critic_updates: int = 20,
    target_update_frequency: int = 1,
    subset_size: int = 2,
    reward_scale: float = 5.0,
    additional_transition: Optional[Any] = None,
    transition_mix_fraction: float = 1.0,  # part of original buffer sample to keep TODO : add control over this hyperparameter
    expert_policy: Optional[Callable] = None,
    imitation_coef: float = 0.0,
    distance_to_stable: Callable = get_one,
    imitation_coef_offset: float = 0.0,
    target_modifier: Optional[Callable] = None,
    obs_preprocessor: Optional[Callable] = None,
    policy_action_transform: Optional[Callable] = None,
    repulsion_coef: float = 0.0,
    extension_stack: Optional[ExtensionStack] = None,
    total_timesteps: int = 1,
    burn_in: int = 8,
    sequence_length: int = 16,
    stored_state: bool = False,
) -> Tuple[REDQState, AuxiliaryLogs]:
    """
    Update the REDQ agent, including critic, actor, and temperature updates.

    Args:
        agent_state (REDQState): Current REDQ agent state.
        _ (Any): Placeholder for scan compatibility.
        buffer (BufferType): Replay buffer.
        recurrent (bool): Whether the model is recurrent.
        gamma (float): Discount factor.
        action_dim (int): Action dimensionality.
        tau (float): Soft update coefficient.
        num_critic_updates (int): Number of critic updates per step.
        target_update_frequency (int): Frequency of target network updates.
        reward_scale (float): Reward scaling factor.

    Returns:
        Tuple[REDQState, None]: Updated agent state.
    """
    # Sample buffer

    sample_key, rng = jax.random.split(agent_state.rng)
    carries = None
    if recurrent:
        # Sequence replay with burned-in carries (R2D2-style); expert
        # features are rejected upstream in make_train.
        transition, carries = sample_and_burnin_sequences(
            agent_state, buffer, sample_key, burn_in, stored_state=stored_state
        )
        raw_observations = None
    elif buffer is not None and agent_state.collector_state.buffer_state is not None:
        (
            observations,
            terminated,
            truncated,
            next_observations,
            rewards,
            actions,
            raw_observations,
            _,
        ) = get_batch_from_buffer(
            buffer,
            agent_state.collector_state.buffer_state,
            sample_key,
        )
        original_transition = Transition(
            observations, actions, rewards, terminated, truncated, next_observations
        )

        if additional_transition is not None and transition_mix_fraction < 1.0:
            assert transition_mix_fraction >= 0 and transition_mix_fraction <= 1.0, (
                "transition_mix_fraction should be between 0 and 1, got",
                transition_mix_fraction,
            )
            len_original = len(observations)
            n_samples_from_original = floor(transition_mix_fraction * len_original)
            n_samples_from_transition = len_original - n_samples_from_original
            print(
                f"samples from buffer:{n_samples_from_original} online"
                f" samples:{n_samples_from_transition}"
            )
            additional_transition = jax.tree.map(
                lambda x: jax.random.choice(
                    sample_key, x, shape=(n_samples_from_transition,)
                ),
                additional_transition,
            )

            transition = jax.tree.map(
                lambda x, y: (
                    None
                    if (x is None or y is None)
                    else jnp.concatenate([x[:n_samples_from_original], y], axis=0)
                ),
                original_transition,
                additional_transition,
                is_leaf=lambda x: x is None,
            )
        else:
            transition = original_transition
    elif additional_transition is not None:
        # If no buffer is provided, use the collector state to get the latest transition
        transition = additional_transition
        terminated = additional_transition.terminated
        truncated = additional_transition.truncated

    agent_state = agent_state.replace(rng=rng)
    dones = jnp.logical_or(transition.terminated, transition.truncated)

    # Precompute expert action once when needed by policy_action_transform
    a_expert_precomputed = None
    if expert_policy is not None and policy_action_transform is not None:
        _raw = raw_observations if raw_observations is not None else transition.obs
        a_expert_precomputed = jax.lax.stop_gradient(expert_policy(_raw))

    # Update Q functions
    def critic_update_step(carry, _):
        agent_state = carry
        agent_state, aux_value = update_value_functions(
            observations=transition.obs,
            actions=transition.action,
            next_observations=transition.next_obs,
            rewards=transition.reward,
            dones=dones,
            agent_state=agent_state,
            recurrent=recurrent,
            gamma=gamma,
            reward_scale=reward_scale,
            subset_size=subset_size,
            target_modifier=target_modifier,
            repulsion_coef=repulsion_coef,
            extension_stack=extension_stack,
            total_timesteps=total_timesteps,
            carries=carries,
        )
        agent_state = update_target_networks(agent_state, tau=tau)

        return agent_state, aux_value

    # See ajax.perf_utils.final_aux_scan: carry-only scan that exposes
    # last-step aux without materialising the leading scan axis on
    # device. Same pattern as SAC's critic-update scan.
    agent_state, aux_value = final_aux_scan(
        critic_update_step,
        agent_state,
        length=num_critic_updates,
    )

    # Update policy
    agent_state, aux_policy, log_probs = update_policy(
        observations=transition.obs,
        done=dones,
        agent_state=agent_state,
        recurrent=recurrent,
        raw_observations=raw_observations,
        expert_policy=expert_policy,
        imitation_coef=imitation_coef,
        distance_to_stable=distance_to_stable,
        imitation_coef_offset=imitation_coef_offset,
        a_expert_precomputed=a_expert_precomputed,
        obs_preprocessor=obs_preprocessor,
        policy_action_transform=policy_action_transform,
        extension_stack=extension_stack,
        total_timesteps=total_timesteps,
        carries=carries,
    )

    # Adjust temperature
    effective_target_entropy = jnp.array(-float(action_dim))
    agent_state, aux_temperature = update_temperature(  # type: ignore[assignment]
        agent_state,  # type: ignore[arg-type]
        log_probs=log_probs,
        effective_target_entropy=effective_target_entropy,
    )

    # Update target networks
    # TODO : Only update every update_target_network steps

    aux = AuxiliaryLogs(
        temperature=aux_temperature,
        policy=aux_policy,
        value=ValueAuxiliaries(
            **{key: val.flatten() for key, val in to_state_dict(aux_value).items()}
        ),
    )
    return agent_state, aux


@partial(
    jax.jit,
    static_argnames=[
        "env_args",
        "mode",
        "recurrent",
        "buffer",
        "log_frequency",
        "num_episode_test",
        "log_fn",
        "log",
        "verbose",
        "action_dim",
        "lstm_hidden_size",
        "agent_config",
        "horizon",
        "total_timesteps",
        "n_epochs",
        "transition_mix_fraction",
        "expert_policy",
        "imitation_coef",
        "distance_to_stable",
        "imitation_coef_offset",
        "action_scale",
        "action_pipeline",
        "eval_action_transform",
        "target_modifier",
        "obs_preprocessor",
        "policy_action_transform",
        "extension_stack",
    ],
)
def training_iteration(
    agent_state: REDQState,
    _: Any,
    env_args: EnvironmentConfig,
    mode: str,
    recurrent: bool,
    buffer: BufferType,
    agent_config: REDQConfig,
    action_dim: int,
    total_timesteps: int,
    lstm_hidden_size: Optional[int] = None,
    log_frequency: int = 1000,
    horizon: int = 10000,
    num_episode_test: int = 10,
    log_fn: Optional[Callable] = None,
    index: Optional[int] = None,
    log: bool = False,
    verbose: bool = False,
    n_epochs: int = 1,
    transition_mix_fraction: float = 1.0,
    expert_policy: Optional[Callable] = None,
    imitation_coef: float = 1e-3,
    distance_to_stable: Callable = get_one,
    imitation_coef_offset: float = 1e-3,
    action_scale: float = 1.0,
    action_pipeline: Optional[Callable] = None,
    eval_action_transform: Optional[Callable] = None,
    target_modifier: Optional[Callable] = None,
    obs_preprocessor: Optional[Callable] = None,
    policy_action_transform: Optional[Callable] = None,
    extension_stack: Optional[ExtensionStack] = None,
) -> tuple[REDQState, None]:
    """
    Perform one training iteration, including experience collection and agent updates.

    Args:
        agent_state (REDQState): Current REDQ agent state.
        _ (Any): Placeholder for scan compatibility.
        env_args (EnvironmentConfig): Environment configuration.
        mode (str): Environment mode ("gymnax" or "brax").
        recurrent (bool): Whether the model is recurrent.
        buffer (BufferType): Replay buffer.
        agent_config (REDQConfig): REDQ agent configuration.
        action_dim (int): Action dimensionality.
        lstm_hidden_size (Optional[int]): LSTM hidden size for recurrent models.
        log_frequency (int): Frequency of logging and evaluation.
        num_episode_test (int): Number of episodes for evaluation.

    Returns:
        Tuple[REDQState, None]: Updated agent state.
    """
    # collector_state = agent_state.collector_state

    timestep = agent_state.collector_state.timestep
    uniform = should_use_uniform_sampling(timestep, agent_config.learning_starts)

    collect_scan_fn = partial(
        collect_experience,
        store_hidden=recurrent and agent_config.stored_state,
        recurrent=recurrent,
        mode=mode,
        env_args=env_args,
        buffer=buffer,
        uniform=uniform,
        action_pipeline=action_pipeline,
    )

    agent_state, transition = jax.lax.scan(
        collect_scan_fn, agent_state, xs=None, length=1
    )
    timestep = agent_state.collector_state.timestep

    def do_update(agent_state):
        update_scan_fn = partial(
            update_agent,
            buffer=buffer,
            recurrent=recurrent,
            gamma=agent_config.gamma,
            action_dim=action_dim,
            tau=agent_config.tau,
            reward_scale=agent_config.reward_scale,
            additional_transition=(
                jax.tree.map(lambda x: x.squeeze(0), transition)
                if transition_mix_fraction < 1.0
                else None
            ),
            transition_mix_fraction=transition_mix_fraction,
            expert_policy=expert_policy,
            imitation_coef=imitation_coef,
            distance_to_stable=distance_to_stable,
            imitation_coef_offset=imitation_coef_offset,
            num_critic_updates=agent_config.num_critic_updates,
            subset_size=agent_config.subset_size,
            target_modifier=target_modifier,
            obs_preprocessor=obs_preprocessor,
            policy_action_transform=policy_action_transform,
            repulsion_coef=agent_config.repulsion_coef,
            extension_stack=extension_stack,
            total_timesteps=total_timesteps,
            burn_in=agent_config.burn_in,
            sequence_length=agent_config.sequence_length,
            stored_state=agent_config.stored_state,
        )
        agent_state, aux = jax.lax.scan(
            update_scan_fn, agent_state, xs=None, length=n_epochs
        )
        aux = jax.tree.map(
            lambda x: x[-1].reshape((1,)), aux
        )  # keep only the final state across epochs
        aux = aux.replace(
            value=ValueAuxiliaries(
                **{key: val.flatten() for key, val in to_state_dict(aux.value).items()}
            )
        )

        # Extension post_update — folded once per training_iteration,
        # after the n-epochs scan. Empty stack ⇒ identity.
        if extension_stack is not None:
            _pu_rng, _pu_rng2 = jax.random.split(agent_state.rng)
            agent_state = agent_state.replace(rng=_pu_rng2)
            agent_state = extension_stack.fold_post_update(
                agent_state,
                agent_state.collector_state.timestep,
                _pu_rng,
                total_timesteps,
            )
        return agent_state, aux

    def fill_with_nan(dataclass):
        """
        Recursively fills all fields of a dataclass with jnp.nan.
        """
        nan = jnp.ones(1) * jnp.nan
        dict = {}
        for field in fields(dataclass):
            sub_dataclass = field.type
            if hasattr(
                sub_dataclass, "__dataclass_fields__"
            ):  # Check if the field is another dataclass
                dict[field.name] = fill_with_nan(sub_dataclass)
            else:
                dict[field.name] = nan
        return dataclass(**dict)

    def skip_update(agent_state):
        return agent_state, fill_with_nan(AuxiliaryLogs)

    agent_state, aux = jax.lax.cond(
        timestep >= agent_config.learning_starts,
        do_update,
        skip_update,
        operand=agent_state,
    )

    _extra_eval = compose_eval_metrics(None, extension_stack, total_timesteps)
    agent_state, metrics_to_log = evaluate_and_log(
        agent_state,
        aux,
        index,
        mode,
        env_args,
        num_episode_test,
        recurrent,
        lstm_hidden_size,
        log,
        verbose,
        log_fn,
        log_frequency,
        total_timesteps,
        expert_policy=expert_policy,
        action_scale=action_scale,
        eval_action_transform=eval_action_transform,
        extra_eval_metrics=_extra_eval,
    )

    return agent_state, metrics_to_log


def make_train(
    env_args: EnvironmentConfig,
    actor_optimizer_args: OptimizerConfig,
    critic_optimizer_args: OptimizerConfig,
    network_args: NetworkConfig,
    buffer: BufferType,
    agent_config: REDQConfig,
    alpha_args: AlphaConfig,
    total_timesteps: int,
    num_episode_test: int,
    run_ids: Optional[Sequence[str]] = None,
    logging_config: Optional[LoggingConfig] = None,
    cloning_args: Optional[CloningConfig] = None,
    expert_policy: Optional[Callable] = None,
    pid_actor_config: Optional[PIDActorConfig] = None,
    action_pipeline: Optional[Callable] = None,
    eval_action_transform: Optional[Callable] = None,
    target_modifier: Optional[Callable] = None,
    obs_preprocessor: Optional[Callable] = None,
    policy_action_transform: Optional[Callable] = None,
    extensions: Sequence = (),
):
    """
    Create the training function for the REDQ agent.

    Args:
        env_args (EnvironmentConfig): Environment configuration.
        optimizer_args (OptimizerConfig): Optimizer configuration.
        network_args (NetworkConfig): Network configuration.
        buffer (BufferType): Replay buffer.
        agent_config (REDQConfig): REDQ agent configuration.
        alpha_args (AlphaConfig): Alpha configuration.
        total_timesteps (int): Total timesteps for training.
        num_episode_test (int): Number of episodes for evaluation during training.

    Returns:
        Callable: JIT-compiled training function.
    """
    mode = "gymnax" if check_env_is_gymnax(env_args.env) else "brax"
    log = logging_config is not None
    log_fn = partial(vmap_log, run_ids=run_ids, logging_config=logging_config)

    _recurrent = (
        resolve_memory_config(network_args.memory, network_args.lstm_hidden_size)
        is not None
    )
    if _recurrent:
        unsupported_recurrent_options(
            "REDQ",
            expert_policy=expert_policy,
            target_modifier=target_modifier,
            policy_action_transform=policy_action_transform,
            obs_preprocessor=obs_preprocessor,
            action_pipeline=action_pipeline,
            extensions=(tuple(extensions) or None),
            # REDQ always builds a default CloningConfig; only actual
            # pre-training (pre_train_n_steps > 0) conflicts with memory.
            cloning_pretrain=(
                cloning_args
                if cloning_args is not None and cloning_args.pre_train_n_steps > 0
                else None
            ),
            pid_actor_config=pid_actor_config,
        )

    # Start async logging if logging is enabled
    if logging_config is not None:
        start_async_logging()

    extension_stack = ExtensionStack(extensions) if extensions else None

    @train_jit
    def train(key, index: Optional[int] = None):
        """Train the REDQ agent."""
        init_key, expert_key = jax.random.split(key)
        agent_state = init_REDQ(
            key=init_key,
            env_args=env_args,
            actor_optimizer_args=actor_optimizer_args,
            critic_optimizer_args=critic_optimizer_args,
            network_args=network_args,
            stored_state=agent_config.stored_state,
            alpha_args=alpha_args,
            buffer=buffer,
            number_of_critics=agent_config.num_critics,
            pid_actor_config=pid_actor_config,
        )

        # pre-train agent
        (
            cloning_parameters,
            pre_train_n_steps,
        ) = get_cloning_args(cloning_args, total_timesteps)
        if pre_train_n_steps > 0:
            agent_state = get_pre_trained_agent(
                agent_state,
                expert_policy,
                expert_key,
                env_args,
                cloning_args,
                mode,
                agent_config,
                actor_optimizer_args,
                critic_optimizer_args,
            )

        if extension_stack is not None:
            _ext_key, _pre_key = jax.random.split(expert_key)
            agent_state = extension_stack.fold_init_states(agent_state, _ext_key)
            agent_state = extension_stack.fold_pretrain(
                agent_state, jnp.asarray(0), _pre_key, total_timesteps
            )

        num_updates = total_timesteps // env_args.n_envs
        _, action_shape = get_state_action_shapes(env_args.env)

        training_iteration_scan_fn = partial(
            training_iteration,
            buffer=buffer,
            recurrent=_recurrent,
            action_dim=action_shape[0],
            agent_config=agent_config,
            mode=mode,
            env_args=env_args,
            num_episode_test=num_episode_test,
            log_fn=log_fn,
            index=index,
            log=log,
            total_timesteps=total_timesteps,
            log_frequency=(
                logging_config.log_frequency if logging_config is not None else None
            ),
            horizon=(logging_config.horizon if logging_config is not None else None),
            expert_policy=expert_policy,
            action_pipeline=action_pipeline,
            eval_action_transform=eval_action_transform,
            target_modifier=target_modifier,
            obs_preprocessor=obs_preprocessor,
            policy_action_transform=policy_action_transform,
            extension_stack=extension_stack,
            **cloning_parameters,
        )

        agent_state, out = jax.lax.scan(
            f=training_iteration_scan_fn,
            init=agent_state,
            xs=None,
            length=num_updates,
        )

        return agent_state, out

    return train
