import time
import uuid
from collections.abc import Sequence
from typing import Callable, Optional, Union

import jax
import jax.numpy as jnp
from gymnax import EnvParams

# Defensive: a broken wandb install must not crash Ajax imports —
# downstream callers using TensorBoard-only (use_wandb=False) should
# still work. ``wandb.util.generate_id()`` is only reached when a
# ``LoggingConfig`` was passed; in that branch we fall back to
# ``uuid.uuid4().hex`` if wandb didn't import.
try:
    import wandb  # type: ignore[import-untyped]
except ImportError:
    wandb = None  # type: ignore[assignment]

from ajax.environments.create import prepare_env
from ajax.extensions.base import Extension, ExtensionStack
from ajax.logging.wandb_logging import (
    LoggingConfig,
    init_logging,
    stop_async_logging,
)
from ajax.networks.memory import MemoryConfig, resolve_memory_config
from ajax.state import (
    BaseAgentConfig,
    BaseAgentState,
    EnvironmentConfig,
    NetworkConfig,
    OptimizerConfig,
)
from ajax.types import EnvType, InitializationFunction


class ActorCritic:
    # Agents that implement recurrent (memory-augmented) training set this
    # to True; every other agent gets a loud error instead of a silent
    # misconfiguration when `memory` / `lstm_hidden_size` is provided.
    supports_memory: bool = False

    def __init__(  # pylint: disable=W0102, R0913
        self,
        env_id: str | EnvType,  # TODO : see how to handle wrappers?
        n_envs: int = 4,
        actor_learning_rate: float = 3e-4,
        critic_learning_rate: float = 3e-4,
        actor_architecture=("128", "tanh", "128", "tanh"),
        critic_architecture=("128", "tanh", "128", "tanh"),
        env_params: Optional[EnvParams] = None,
        max_grad_norm: Optional[float] = 0.5,
        lstm_hidden_size: Optional[int] = None,
        memory: Optional[Union[MemoryConfig, dict]] = None,
        normalize_observations: bool = False,
        normalize_rewards: bool = False,
        actor_kernel_init: Optional[Union[str, InitializationFunction]] = None,
        actor_bias_init: Optional[Union[str, InitializationFunction]] = None,
        critic_kernel_init: Optional[Union[str, InitializationFunction]] = None,
        critic_bias_init: Optional[Union[str, InitializationFunction]] = None,
        encoder_kernel_init: Optional[Union[str, InitializationFunction]] = None,
        encoder_bias_init: Optional[Union[str, InitializationFunction]] = None,
        cnn_image_shape: Optional[tuple] = None,
        cnn_extra_obs_dim: int = 0,
        cnn_spec: Optional[tuple] = None,
        # Brax-style actor head knobs (see NetworkConfig). Default = legacy.
        log_std_state_independent: bool = False,
        log_std_init: float = -1.0,
        mean_kernel_init: Optional[Union[str, InitializationFunction]] = None,
        disable_encoder_output_norm: bool = False,
        squash: bool = False,
        episode_length: Optional[int] = None,
        apply_obs_normalization: bool = True,
        extensions: Sequence[Extension] = (),
    ) -> None:
        """
        Initialize the PPO agent.

        Args:
            env_id (str | EnvType): Environment ID or environment instance.
            n_envs (int): Number of parallel environments.
            learning_rate (float): Learning rate for optimizers.
            actor_architecture (tuple): Architecture of the actor network.
            critic_architecture (tuple): Architecture of the critic network.
            gamma (float): Discount factor for rewards.
            env_params (Optional[EnvParams]): Parameters for the environment.
            max_grad_norm (Optional[float]): Maximum gradient norm for clipping.
            buffer_size (int): Size of the replay buffer.
            batch_size (int): Batch size for training.
            learning_starts (int): Timesteps before training starts.
            tau (float): Soft update coefficient for target networks.
            reward_scale (float): Scaling factor for rewards.
            alpha_init (float): Initial value for the temperature parameter.
            target_entropy_per_dim (float): Target entropy per action dimension.
            lstm_hidden_size (Optional[int]): Hidden size for LSTM (if used).
        """

        # Resolve the memory config once: explicit `memory` wins; the legacy
        # `lstm_hidden_size` maps to a GRU (its historical behaviour).
        memory = resolve_memory_config(memory, lstm_hidden_size)
        if memory is not None and not self.supports_memory:
            raise NotImplementedError(
                f"{type(self).__name__} does not support recurrent networks"
                " (memory / lstm_hidden_size) yet; supported agents:"
                " PPO, SAC, ASAC, REDQ, TD3."
            )

        env, env_params, env_id, continuous = prepare_env(
            env_id,
            env_params=env_params,
            normalize_obs=normalize_observations,
            normalize_reward=normalize_rewards,
            n_envs=n_envs,
            episode_length=episode_length,
            apply_obs_normalization=apply_obs_normalization,
        )

        self.env_args = EnvironmentConfig(
            env=env,
            env_params=env_params,
            n_envs=n_envs,
            continuous=continuous,
        )

        self.network_args = NetworkConfig(
            actor_architecture=actor_architecture,
            critic_architecture=critic_architecture,
            memory=memory,
            actor_kernel_init=actor_kernel_init,
            actor_bias_init=actor_bias_init,
            critic_kernel_init=critic_kernel_init,
            critic_bias_init=critic_bias_init,
            encoder_kernel_init=encoder_kernel_init,
            encoder_bias_init=encoder_bias_init,
            cnn_image_shape=cnn_image_shape,
            cnn_extra_obs_dim=cnn_extra_obs_dim,
            cnn_spec=cnn_spec,
            log_std_state_independent=log_std_state_independent,
            log_std_init=log_std_init,
            mean_kernel_init=mean_kernel_init,
            disable_encoder_output_norm=disable_encoder_output_norm,
            squash=squash,
        )

        self.actor_optimizer_args = OptimizerConfig(
            learning_rate=actor_learning_rate,
            max_grad_norm=max_grad_norm,
            clipped=max_grad_norm is not None,
        )
        self.critic_optimizer_args = OptimizerConfig(
            learning_rate=critic_learning_rate,
            max_grad_norm=max_grad_norm,
            clipped=max_grad_norm is not None,
        )

        self.agent_config = BaseAgentConfig()

        # Composable research features (expert guidance, instrumentation,
        # …). The stack is static — agents thread it into make_train as a
        # static argument and fold it at the phase points of their
        # training step. An empty stack is a true no-op. See
        # `ajax.extensions.base`.
        self.extension_stack = ExtensionStack(extensions)

    def get_make_train(self) -> Callable:
        raise NotImplementedError

    # @with_wandb_silent
    def train(
        self,
        seed: int | Sequence[int] = 42,
        n_timesteps: int = int(1e6),
        num_episode_test: int = 10,
        logging_config: Optional[LoggingConfig] = None,
        on_ids_ready: Optional[Callable] = None,
        initial_state: Optional[BaseAgentState] = None,
        **kwargs,
    ) -> BaseAgentState:
        """
        Train the PPO agent.

        Args:
            seed (int | Sequence[int]): Random seed(s) for training.
            n_timesteps (int): Total number of timesteps for training.
            num_episode_test (int): Number of episodes for evaluation during training.
        """
        if isinstance(seed, int):
            seed = [seed]

        if logging_config is not None:
            logging_config.config.update(self.config)
            _gen_id = (
                wandb.util.generate_id
                if wandb is not None
                else lambda: uuid.uuid4().hex
            )
            self.run_ids = [_gen_id() for _ in range(len(seed))]
            for run_id, run_seed in zip(self.run_ids, seed):
                init_logging(run_id, logging_config, run_seed=int(run_seed))

        else:
            self.run_ids = []

        if on_ids_ready is not None:
            on_ids_ready(self.run_ids)

        train_jit = self.get_make_train()(
            env_args=self.env_args,
            actor_optimizer_args=self.actor_optimizer_args,
            critic_optimizer_args=self.critic_optimizer_args,
            network_args=self.network_args,
            agent_config=self.agent_config,
            total_timesteps=n_timesteps,
            num_episode_test=num_episode_test,
            run_ids=self.run_ids,
            logging_config=logging_config,
            **kwargs,
        )

        if initial_state is None:

            def set_key_and_train(seed, index):
                key = jax.random.PRNGKey(seed)
                return train_jit(key, index)

            index = jnp.arange(len(seed))
            seed = jnp.array(seed)
            _t0 = time.time()
            result = jax.vmap(set_key_and_train, in_axes=0)(seed, index)
        else:
            # Resume path. ``agent.train()`` returns a 2-tuple ``(state, metrics)``;
            # accept either form of ``initial_state`` and strip the metrics if
            # provided so the inner train_jit receives only the agent state.
            if isinstance(initial_state, tuple) and len(initial_state) == 2:
                initial_state = initial_state[0]

            def set_key_and_train_resume(seed, index, state):
                key = jax.random.PRNGKey(seed)
                return train_jit(
                    key,
                    index,
                    initial_state=state,
                    resume_from_state=True,
                )

            index = jnp.arange(len(seed))
            seed = jnp.array(seed)
            _t0 = time.time()
            result = jax.vmap(set_key_and_train_resume, in_axes=(0, 0, 0))(
                seed, index, initial_state
            )
        # Block until all XLA computation and debug.callbacks complete, then
        # drain and stop the logging worker.  Calling stop_async_logging()
        # inside the vmapped function was wrong: it ran as a Python side effect
        # during vmap *tracing* (before any training executed), killing the
        # worker before any log events were queued.
        jax.block_until_ready(result)
        stop_async_logging()
        return result
